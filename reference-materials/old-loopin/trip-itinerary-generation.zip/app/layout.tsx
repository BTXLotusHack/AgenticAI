import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { ThemeProvider } from '@/components/theme-provider'
import { AuthProvider } from '@/lib/auth-context'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: 'Loopin - Smart Travel Planning | Discover Hidden Gems',
    template: '%s | Loopin',
  },
  description: 'Plan personalized city trips with AI-powered itineraries. Discover hidden gems, optimize routes, and connect with travelers. Start your adventure today.',
  keywords: ['travel planning', 'trip planner', 'hidden gems', 'AI travel', 'itinerary', 'city trips'],
  authors: [{ name: 'Loopin' }],
  creator: 'Loopin',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    title: 'Loopin - Smart Travel Planning',
    description: 'Plan personalized city trips with AI-powered itineraries. Discover hidden gems and travel smarter.',
    siteName: 'Loopin',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Loopin - Smart Travel Planning',
    description: 'Plan personalized city trips with AI-powered itineraries. Discover hidden gems and travel smarter.',
  },
  robots: {
    index: true,
    follow: true,
  },
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-sans antialiased bg-background">
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
