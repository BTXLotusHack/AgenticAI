import { openai } from "@ai-sdk/openai"
import { generateText } from "ai"
import { createClient } from "@/lib/supabase/server"

export async function POST(req: Request) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const {
      destination,
      startDate,
      endDate,
      partySize = 2,
      budgetLevel = "mid-range",
      interests = ["culture", "food"],
      travelPace = "balanced",
      hiddenGemsOnly = false,
    } = body

    // Calculate number of days
    let numberOfDays = 3
    if (startDate && endDate) {
      numberOfDays = Math.ceil(
        (new Date(endDate).getTime() - new Date(startDate).getTime()) /
          (1000 * 60 * 60 * 24)
      ) + 1
    }

    const budgetMap: Record<string, number> = {
      "budget": 1,
      "mid-range": 2,
      "luxury": 3
    }
    const budgetNum = typeof budgetLevel === "number" ? budgetLevel : (budgetMap[budgetLevel] || 2)

    const { text } = await generateText({
      model: openai("gpt-4o-mini"),
      prompt: `You are a travel planning expert. Generate a detailed ${numberOfDays}-day itinerary for ${destination}.

Trip Details:
- Party size: ${partySize} ${partySize === 1 ? "person" : "people"}
- Budget level: ${budgetNum} (1=budget, 2=mid-range, 3=luxury)
- Interests: ${Array.isArray(interests) ? interests.join(", ") : interests}
- Travel pace: ${travelPace} (relaxed=2-3 stops/day, balanced=4-5 stops/day, packed=6+ stops/day)
- Hidden gems preference: ${hiddenGemsOnly ? "Focus on hidden gems and local favorites" : "Mix of popular and hidden spots"}

Return a JSON object with this exact structure:
{
  "destination": {
    "city": "City Name",
    "country": "Country",
    "description": "Brief description of the city"
  },
  "days": [
    {
      "dayNumber": 1,
      "theme": "Day theme like 'Cultural Immersion'",
      "stops": [
        {
          "name": "Place name",
          "description": "Brief description",
          "category": "temple|museum|restaurant|cafe|park|market|neighborhood|nightlife|shopping",
          "startTime": "09:00",
          "duration": 90,
          "estimatedCost": 0,
          "isHiddenGem": false,
          "tags": ["culture", "history"],
          "address": "Full address",
          "latitude": 35.6762,
          "longitude": 139.6503
        }
      ]
    }
  ],
  "totalEstimatedCost": 150,
  "tips": ["Useful travel tip 1", "Useful travel tip 2"]
}

Only return valid JSON, no markdown or explanation.`,
    })

    // Parse the response
    let itinerary
    try {
      const cleanedText = text.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim()
      itinerary = JSON.parse(cleanedText)
    } catch {
      return Response.json(
        { error: "Failed to parse itinerary", raw: text },
        { status: 500 }
      )
    }

    // Save trip to database
    const tripStartDate = startDate || new Date().toISOString().split("T")[0]
    const tripEndDate = endDate || new Date(Date.now() + (numberOfDays - 1) * 24 * 60 * 60 * 1000).toISOString().split("T")[0]

    const { data: trip, error: tripError } = await supabase
      .from("trips")
      .insert({
        user_id: user.id,
        name: `${itinerary.destination.city} Trip`,
        destination_city: itinerary.destination.city,
        destination_country: itinerary.destination.country,
        destination_image: `https://images.unsplash.com/photo-1480796927426-f609979314bd?w=800`,
        start_date: tripStartDate,
        end_date: tripEndDate,
        party_size: partySize,
        budget_level: typeof budgetLevel === "string" ? budgetLevel : "mid-range",
        interests: Array.isArray(interests) ? interests : [interests],
        travel_pace: travelPace,
        hidden_gems_only: hiddenGemsOnly,
      })
      .select()
      .single()

    if (tripError) {
      return Response.json({ error: "Failed to save trip", details: tripError.message }, { status: 500 })
    }

    // Save days and stops
    for (const day of itinerary.days) {
      const dayDate = new Date(tripStartDate)
      dayDate.setDate(dayDate.getDate() + day.dayNumber - 1)

      const { data: tripDay, error: dayError } = await supabase
        .from("trip_days")
        .insert({
          trip_id: trip.id,
          day_number: day.dayNumber,
          date: dayDate.toISOString().split("T")[0],
          estimated_cost: day.stops.reduce((sum: number, s: { estimatedCost?: number }) => sum + (s.estimatedCost || 0), 0),
        })
        .select()
        .single()

      if (dayError) continue

      for (let i = 0; i < day.stops.length; i++) {
        const stop = day.stops[i]

        const { data: place, error: placeError } = await supabase
          .from("places")
          .insert({
            name: stop.name,
            description: stop.description,
            address: stop.address || "",
            city: itinerary.destination.city,
            country: itinerary.destination.country,
            latitude: stop.latitude,
            longitude: stop.longitude,
            image: `https://images.unsplash.com/photo-1480796927426-f609979314bd?w=400`,
            category: stop.category,
            tags: stop.tags || [],
            price_level: budgetNum,
            is_hidden_gem: stop.isHiddenGem || false,
          })
          .select()
          .single()

        if (placeError) continue

        await supabase
          .from("day_stops")
          .insert({
            trip_day_id: tripDay.id,
            place_id: place.id,
            start_time: stop.startTime,
            duration_minutes: stop.duration || 60,
            estimated_cost: stop.estimatedCost || 0,
            order_index: i,
          })
      }
    }

    return Response.json({
      success: true,
      tripId: trip.id,
      itinerary,
    })
  } catch (error) {
    return Response.json(
      { error: "Failed to generate itinerary", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    )
  }
}
