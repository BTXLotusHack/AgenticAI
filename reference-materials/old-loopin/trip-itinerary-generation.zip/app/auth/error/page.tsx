import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Compass, AlertCircle, ArrowLeft, RefreshCw } from "lucide-react"

export default function AuthErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; error_description?: string }>
}) {
  return (
    <AuthErrorContent searchParams={searchParams} />
  )
}

async function AuthErrorContent({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; error_description?: string }>
}) {
  const params = await searchParams
  const error = params.error || "unknown_error"
  const errorDescription =
    params.error_description || "An unexpected error occurred during authentication."

  const errorMessages: Record<string, { title: string; description: string }> = {
    access_denied: {
      title: "Access Denied",
      description: "You denied access to your account. Please try again if this was a mistake.",
    },
    invalid_request: {
      title: "Invalid Request",
      description: "The authentication request was invalid. Please try signing in again.",
    },
    server_error: {
      title: "Server Error",
      description: "We encountered a server error. Please try again in a few moments.",
    },
    temporarily_unavailable: {
      title: "Service Unavailable",
      description: "The authentication service is temporarily unavailable. Please try again later.",
    },
    unknown_error: {
      title: "Something went wrong",
      description: errorDescription,
    },
  }

  const { title, description } = errorMessages[error] || errorMessages.unknown_error

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
      <div className="w-full max-w-md text-center">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
            <Compass className="h-7 w-7 text-primary-foreground" />
          </div>
        </div>

        {/* Error Icon */}
        <div className="mb-6 flex justify-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-destructive/10">
            <AlertCircle className="h-10 w-10 text-destructive" />
          </div>
        </div>

        <h1 className="mb-3 text-3xl font-bold text-foreground">{title}</h1>
        <p className="mb-8 text-muted-foreground leading-relaxed">{description}</p>

        <div className="flex flex-col gap-3">
          <Button asChild className="w-full h-12">
            <Link href="/auth/login">
              <RefreshCw className="mr-2 h-4 w-4" />
              Try again
            </Link>
          </Button>

          <Button asChild variant="outline" className="w-full h-12">
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go back home
            </Link>
          </Button>
        </div>

        <p className="mt-8 text-sm text-muted-foreground">
          If this problem persists,{" "}
          <Link href="/support" className="text-primary hover:underline">
            contact our support team
          </Link>
        </p>
      </div>
    </div>
  )
}
