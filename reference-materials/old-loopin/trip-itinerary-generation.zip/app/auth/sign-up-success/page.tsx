import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Compass, Mail, ArrowRight, CheckCircle2 } from "lucide-react"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
      <div className="w-full max-w-md text-center">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
            <Compass className="h-7 w-7 text-primary-foreground" />
          </div>
        </div>

        {/* Success Icon */}
        <div className="mb-6 flex justify-center">
          <div className="relative">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
              <Mail className="h-10 w-10 text-primary" />
            </div>
            <div className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-green-500">
              <CheckCircle2 className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>

        <h1 className="mb-3 text-3xl font-bold text-foreground">Check your email</h1>
        <p className="mb-8 text-muted-foreground leading-relaxed">
          We&apos;ve sent you a confirmation link to verify your email address. 
          Click the link in the email to activate your account and start planning your trips.
        </p>

        <div className="space-y-4">
          <div className="rounded-lg border bg-muted/30 p-4">
            <h3 className="mb-2 font-medium text-foreground">Didn&apos;t receive the email?</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>Check your spam or junk folder</li>
              <li>Make sure you entered the correct email</li>
              <li>Wait a few minutes and try again</li>
            </ul>
          </div>

          <Button asChild className="w-full h-12">
            <Link href="/auth/login">
              Go to login
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>

          <p className="text-sm text-muted-foreground">
            Need help?{" "}
            <Link href="/support" className="text-primary hover:underline">
              Contact support
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
