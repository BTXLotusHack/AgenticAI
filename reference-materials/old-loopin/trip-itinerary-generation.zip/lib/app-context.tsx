"use client"

import React, { createContext, useContext, useState, useCallback } from "react"
import type { Trip, User, Place, DayStop, DayPlan, TripPreferences, City, TravelerPresence } from "./types"
import { sampleTrip, sampleUsers, cities, places, tokyoTravelers, swapSuggestions } from "./sample-data"

// ============ App State ============
interface AppState {
  // User
  currentUser: User | null
  isAuthenticated: boolean
  
  // Navigation
  activeTab: "trips" | "explore" | "now" | "social" | "profile"
  
  // Trips
  trips: Trip[]
  currentTrip: Trip | null
  selectedDayIndex: number
  selectedStop: DayStop | null
  
  // Discovery
  currentCity: City | null
  
  // Social
  cityTravelers: TravelerPresence[]
  
  // UI State
  isTripWizardOpen: boolean
  isShareDialogOpen: boolean
  wizardStep: number
}

// ============ Actions ============
interface AppActions {
  // Auth
  login: (user: User) => void
  logout: () => void
  
  // Navigation
  setActiveTab: (tab: AppState["activeTab"]) => void
  
  // Trips
  setCurrentTrip: (trip: Trip | null) => void
  createTrip: (trip: Trip) => void
  updateTrip: (tripId: string, updates: Partial<Trip>) => void
  deleteTrip: (tripId: string) => void
  selectDay: (index: number) => void
  selectStop: (stop: DayStop | null) => void
  
  // Day Planning
  addStop: (dayIndex: number, stop: DayStop) => void
  removeStop: (dayIndex: number, stopId: string) => void
  reorderStops: (dayIndex: number, stops: DayStop[]) => void
  swapStop: (dayIndex: number, oldStopId: string, newPlace: Place) => void
  
  // Discovery
  setCurrentCity: (city: City) => void
  
  // UI
  openTripWizard: () => void
  closeTripWizard: () => void
  setWizardStep: (step: number) => void
  openShareDialog: () => void
  closeShareDialog: () => void
  
  // Helpers
  getSwapSuggestion: (placeId: string) => typeof swapSuggestions[0] | undefined
}

// ============ Context ============
const AppContext = createContext<(AppState & AppActions) | null>(null)

// ============ Provider ============
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>({
    currentUser: sampleUsers[0],
    isAuthenticated: true,
    activeTab: "trips",
    trips: [sampleTrip],
    currentTrip: sampleTrip,
    selectedDayIndex: 0,
    selectedStop: sampleTrip.days[0]?.stops[0] || null,
    currentCity: cities[0],
    cityTravelers: tokyoTravelers,
    isTripWizardOpen: false,
    isShareDialogOpen: false,
    wizardStep: 0,
  })

  // Auth actions
  const login = useCallback((user: User) => {
    setState(s => ({ ...s, currentUser: user, isAuthenticated: true }))
  }, [])

  const logout = useCallback(() => {
    setState(s => ({ ...s, currentUser: null, isAuthenticated: false }))
  }, [])

  // Navigation
  const setActiveTab = useCallback((tab: AppState["activeTab"]) => {
    setState(s => ({ ...s, activeTab: tab }))
  }, [])

  // Trips
  const setCurrentTrip = useCallback((trip: Trip | null) => {
    setState(s => ({ 
      ...s, 
      currentTrip: trip,
      selectedDayIndex: 0,
      selectedStop: trip?.days[0]?.stops[0] || null,
    }))
  }, [])

  const createTrip = useCallback((trip: Trip) => {
    setState(s => ({ ...s, trips: [...s.trips, trip], currentTrip: trip }))
  }, [])

  const updateTrip = useCallback((tripId: string, updates: Partial<Trip>) => {
    setState(s => ({
      ...s,
      trips: s.trips.map(t => t.id === tripId ? { ...t, ...updates } : t),
      currentTrip: s.currentTrip?.id === tripId 
        ? { ...s.currentTrip, ...updates } 
        : s.currentTrip,
    }))
  }, [])

  const deleteTrip = useCallback((tripId: string) => {
    setState(s => ({
      ...s,
      trips: s.trips.filter(t => t.id !== tripId),
      currentTrip: s.currentTrip?.id === tripId ? null : s.currentTrip,
    }))
  }, [])

  const selectDay = useCallback((index: number) => {
    setState(s => {
      const day = s.currentTrip?.days[index]
      return {
        ...s,
        selectedDayIndex: index,
        selectedStop: day?.stops[0] || null,
      }
    })
  }, [])

  const selectStop = useCallback((stop: DayStop | null) => {
    setState(s => ({ ...s, selectedStop: stop }))
  }, [])

  // Day Planning
  const addStop = useCallback((dayIndex: number, stop: DayStop) => {
    setState(s => {
      if (!s.currentTrip) return s
      const newDays = [...s.currentTrip.days]
      newDays[dayIndex] = {
        ...newDays[dayIndex],
        stops: [...newDays[dayIndex].stops, stop],
        estimatedCost: newDays[dayIndex].estimatedCost + stop.place.estimatedCost,
      }
      const updatedTrip = { ...s.currentTrip, days: newDays }
      return {
        ...s,
        currentTrip: updatedTrip,
        trips: s.trips.map(t => t.id === updatedTrip.id ? updatedTrip : t),
      }
    })
  }, [])

  const removeStop = useCallback((dayIndex: number, stopId: string) => {
    setState(s => {
      if (!s.currentTrip) return s
      const newDays = [...s.currentTrip.days]
      const removedStop = newDays[dayIndex].stops.find(st => st.id === stopId)
      newDays[dayIndex] = {
        ...newDays[dayIndex],
        stops: newDays[dayIndex].stops.filter(st => st.id !== stopId),
        estimatedCost: newDays[dayIndex].estimatedCost - (removedStop?.place.estimatedCost || 0),
      }
      const updatedTrip = { ...s.currentTrip, days: newDays }
      return {
        ...s,
        currentTrip: updatedTrip,
        trips: s.trips.map(t => t.id === updatedTrip.id ? updatedTrip : t),
        selectedStop: s.selectedStop?.id === stopId ? null : s.selectedStop,
      }
    })
  }, [])

  const reorderStops = useCallback((dayIndex: number, stops: DayStop[]) => {
    setState(s => {
      if (!s.currentTrip) return s
      const newDays = [...s.currentTrip.days]
      newDays[dayIndex] = { ...newDays[dayIndex], stops }
      const updatedTrip = { ...s.currentTrip, days: newDays }
      return {
        ...s,
        currentTrip: updatedTrip,
        trips: s.trips.map(t => t.id === updatedTrip.id ? updatedTrip : t),
      }
    })
  }, [])

  const swapStop = useCallback((dayIndex: number, oldStopId: string, newPlace: Place) => {
    setState(s => {
      if (!s.currentTrip) return s
      const newDays = [...s.currentTrip.days]
      const oldStop = newDays[dayIndex].stops.find(st => st.id === oldStopId)
      if (!oldStop) return s

      const newStop: DayStop = {
        ...oldStop,
        id: `stop-${Date.now()}`,
        place: newPlace,
      }

      const costDiff = newPlace.estimatedCost - oldStop.place.estimatedCost
      newDays[dayIndex] = {
        ...newDays[dayIndex],
        stops: newDays[dayIndex].stops.map(st => st.id === oldStopId ? newStop : st),
        estimatedCost: newDays[dayIndex].estimatedCost + costDiff,
      }
      
      const updatedTrip = { ...s.currentTrip, days: newDays }
      return {
        ...s,
        currentTrip: updatedTrip,
        trips: s.trips.map(t => t.id === updatedTrip.id ? updatedTrip : t),
        selectedStop: s.selectedStop?.id === oldStopId ? newStop : s.selectedStop,
      }
    })
  }, [])

  // Discovery
  const setCurrentCity = useCallback((city: City) => {
    setState(s => ({ ...s, currentCity: city }))
  }, [])

  // UI
  const openTripWizard = useCallback(() => {
    setState(s => ({ ...s, isTripWizardOpen: true, wizardStep: 0 }))
  }, [])

  const closeTripWizard = useCallback(() => {
    setState(s => ({ ...s, isTripWizardOpen: false, wizardStep: 0 }))
  }, [])

  const setWizardStep = useCallback((step: number) => {
    setState(s => ({ ...s, wizardStep: step }))
  }, [])

  const openShareDialog = useCallback(() => {
    setState(s => ({ ...s, isShareDialogOpen: true }))
  }, [])

  const closeShareDialog = useCallback(() => {
    setState(s => ({ ...s, isShareDialogOpen: false }))
  }, [])

  // Helpers
  const getSwapSuggestion = useCallback((placeId: string) => {
    return swapSuggestions.find(s => s.originalPlace.id === placeId)
  }, [])

  const value: AppState & AppActions = {
    ...state,
    login,
    logout,
    setActiveTab,
    setCurrentTrip,
    createTrip,
    updateTrip,
    deleteTrip,
    selectDay,
    selectStop,
    addStop,
    removeStop,
    reorderStops,
    swapStop,
    setCurrentCity,
    openTripWizard,
    closeTripWizard,
    setWizardStep,
    openShareDialog,
    closeShareDialog,
    getSwapSuggestion,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

// ============ Hook ============
export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within AppProvider")
  }
  return context
}
