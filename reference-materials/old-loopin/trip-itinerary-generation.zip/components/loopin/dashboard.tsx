"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import type { Profile } from "@/lib/auth-context"
import type { Trip } from "@/lib/types"
import Image from "next/image"
import {
  Plus,
  MapPin,
  Calendar,
  Users,
  Sparkles,
  TrendingUp,
  Search,
  ChevronRight,
  Loader2,
  Plane,
  Clock,
  DollarSign,
  Star,
  Compass,
} from "lucide-react"

interface DashboardProps {
  profile: Profile
  trips: Trip[]
  onCreateTrip: () => void
  onSelectTrip: (trip: Trip) => void
  onGenerateItinerary: (destination: string) => Promise<void>
}

const QUICK_DESTINATIONS = [
  { name: "Tokyo", country: "Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400" },
  { name: "Paris", country: "France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400" },
  { name: "New York", country: "USA", image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400" },
  { name: "Barcelona", country: "Spain", image: "https://images.unsplash.com/photo-1583422409516-2895a77efded?w=400" },
]

const TRENDING_DESTINATIONS = [
  { name: "Kyoto", country: "Japan", trend: "+24%", image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=400" },
  { name: "Lisbon", country: "Portugal", trend: "+18%", image: "https://images.unsplash.com/photo-1585208798174-6cedd86e019a?w=400" },
  { name: "Seoul", country: "South Korea", trend: "+15%", image: "https://images.unsplash.com/photo-1538485399081-7191377e8241?w=400" },
]

export function Dashboard({
  profile,
  trips,
  onCreateTrip,
  onSelectTrip,
  onGenerateItinerary,
}: DashboardProps) {
  const [destination, setDestination] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerate = async () => {
    if (!destination.trim()) return
    setIsGenerating(true)
    try {
      await onGenerateItinerary(destination)
    } finally {
      setIsGenerating(false)
      setDestination("")
    }
  }

  const firstName = profile.first_name || "Traveler"
  const initials = `${profile.first_name?.[0] || ""}${profile.last_name?.[0] || ""}`.toUpperCase() || "T"

  return (
    <ScrollArea className="h-full">
      <div className="p-6 pb-12">
        {/* Header */}
        <div className="mb-8 flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold">Welcome back, {firstName}!</h1>
            <p className="mt-1 text-muted-foreground">
              Ready to plan your next adventure?
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button onClick={onCreateTrip} className="gap-2">
              <Plus className="h-4 w-4" />
              New Trip
            </Button>
            <Avatar className="h-12 w-12 border-2 border-primary/20">
              <AvatarImage src={profile.avatar_url || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary">
                {initials}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>

        {/* AI Destination Input */}
        <Card className="mb-8 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
                <Sparkles className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-semibold">AI Trip Planner</h2>
                <p className="text-sm text-muted-foreground">
                  Enter a destination and we&apos;ll create a personalized itinerary
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Where do you want to go? (e.g., Tokyo, Paris, Bali...)"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleGenerate()}
                  className="h-12 pl-10 pr-4"
                  disabled={isGenerating}
                />
              </div>
              <Button
                onClick={handleGenerate}
                disabled={!destination.trim() || isGenerating}
                className="h-12 px-6"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    Generate Itinerary
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="mb-8 grid gap-4 sm:grid-cols-4">
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Plane className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{trips.length}</p>
                <p className="text-sm text-muted-foreground">Trips Planned</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500/10">
                <MapPin className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{trips.length > 0 ? 1 : 0}</p>
                <p className="text-sm text-muted-foreground">Cities Explored</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/10">
                <Star className="h-6 w-6 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {trips.reduce((acc, t) => acc + t.days.flatMap(d => d.stops).filter(s => s.place.isHiddenGem).length, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Hidden Gems Found</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500/10">
                <DollarSign className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  ${trips.reduce((acc, t) => acc + t.days.reduce((a, d) => a + d.estimatedCost, 0), 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Planned</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Your Trips */}
          <div className="lg:col-span-2">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-semibold">Your Trips</h2>
              <Button variant="ghost" size="sm" onClick={onCreateTrip} className="gap-1">
                <Plus className="h-4 w-4" />
                New Trip
              </Button>
            </div>

            {trips.length > 0 ? (
              <div className="grid gap-4">
                {trips.map((trip) => (
                  <Card
                    key={trip.id}
                    className="cursor-pointer transition-all hover:shadow-md hover:border-primary/30"
                    onClick={() => onSelectTrip(trip)}
                  >
                    <CardContent className="p-0">
                      <div className="flex gap-4 p-4">
                        <div className="relative h-24 w-32 flex-shrink-0 overflow-hidden rounded-lg">
                          <Image
                            src={trip.destination.image}
                            alt={trip.destination.name}
                            fill
                            className="object-cover"
                            sizes="128px"
                          />
                        </div>
                        <div className="flex flex-1 flex-col justify-between">
                          <div>
                            <h3 className="font-semibold">{trip.name}</h3>
                            <p className="flex items-center gap-1 text-sm text-muted-foreground">
                              <MapPin className="h-3 w-3" />
                              {trip.destination.name}, {trip.destination.country}
                            </p>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {new Date(trip.startDate).toLocaleDateString("en-US", {
                                month: "short",
                                day: "numeric",
                              })}
                              {" - "}
                              {new Date(trip.endDate).toLocaleDateString("en-US", {
                                month: "short",
                                day: "numeric",
                              })}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {trip.days.length} days
                            </span>
                            <span className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              {trip.partySize} {trip.partySize === 1 ? "traveler" : "travelers"}
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="h-5 w-5 self-center text-muted-foreground" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-muted">
                    <Compass className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="mb-2 font-semibold">No trips yet</h3>
                  <p className="mb-4 max-w-sm text-sm text-muted-foreground">
                    Start planning your first adventure! Use the AI planner above or create a trip manually.
                  </p>
                  <Button onClick={onCreateTrip} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Create Your First Trip
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Quick Destinations */}
            <div className="mt-8">
              <h2 className="mb-4 text-xl font-semibold">Quick Start</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                {QUICK_DESTINATIONS.map((dest) => (
                  <button
                    key={dest.name}
                    onClick={() => {
                      setDestination(dest.name)
                      handleGenerate()
                    }}
                    className="group relative h-32 overflow-hidden rounded-xl"
                  >
                    <Image
                      src={dest.image}
                      alt={dest.name}
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                      sizes="200px"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute bottom-3 left-3 text-left text-white">
                      <p className="font-semibold">{dest.name}</p>
                      <p className="text-xs text-white/80">{dest.country}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile Summary */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Your Travel Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Travel Style</p>
                  <p className="font-medium capitalize">{profile.travel_style || "Balanced"}</p>
                </div>
                <Separator />
                <div>
                  <p className="mb-2 text-sm text-muted-foreground">Interests</p>
                  <div className="flex flex-wrap gap-1">
                    {profile.interests.length > 0 ? (
                      profile.interests.slice(0, 5).map((interest) => (
                        <Badge key={interest} variant="secondary" className="text-xs capitalize">
                          {interest}
                        </Badge>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No interests set</p>
                    )}
                  </div>
                </div>
                <Separator />
                <div>
                  <p className="mb-2 text-sm text-muted-foreground">Budget</p>
                  <p className="font-medium capitalize">{profile.travel_budget || "Mid-range"}</p>
                </div>
              </CardContent>
            </Card>

            {/* Trending */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Trending Now
                </CardTitle>
                <CardDescription>Popular destinations this month</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {TRENDING_DESTINATIONS.map((dest) => (
                  <button
                    key={dest.name}
                    onClick={() => {
                      setDestination(dest.name)
                    }}
                    className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-muted"
                  >
                    <div className="relative h-12 w-12 overflow-hidden rounded-lg">
                      <Image
                        src={dest.image}
                        alt={dest.name}
                        fill
                        className="object-cover"
                        sizes="48px"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{dest.name}</p>
                      <p className="text-xs text-muted-foreground">{dest.country}</p>
                    </div>
                    <Badge variant="secondary" className="bg-green-500/10 text-green-600">
                      {dest.trend}
                    </Badge>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ScrollArea>
  )
}
