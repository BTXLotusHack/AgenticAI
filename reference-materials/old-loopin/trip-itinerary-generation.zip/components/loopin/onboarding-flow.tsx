"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { 
  Compass, 
  ArrowRight, 
  ArrowLeft, 
  User, 
  MapPin, 
  Wallet, 
  Clock, 
  Users, 
  Utensils,
  Sparkles,
  Loader2,
  Check
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface OnboardingData {
  firstName: string
  lastName: string
  travelStyle: string
  interests: string[]
  favoriteDestinations: string[]
  travelBudget: string
  preferredTripLength: string
  travelCompanions: string
  dietaryRestrictions: string[]
}

const INTERESTS = [
  { id: "culture", label: "Culture & History", icon: "🏛️" },
  { id: "food", label: "Food & Dining", icon: "🍜" },
  { id: "nature", label: "Nature & Outdoors", icon: "🌿" },
  { id: "art", label: "Art & Museums", icon: "🎨" },
  { id: "nightlife", label: "Nightlife", icon: "🌙" },
  { id: "shopping", label: "Shopping", icon: "🛍️" },
  { id: "adventure", label: "Adventure", icon: "🧗" },
  { id: "relaxation", label: "Relaxation", icon: "🧘" },
  { id: "photography", label: "Photography", icon: "📸" },
  { id: "local", label: "Local Experience", icon: "🏘️" },
]

const DESTINATIONS = [
  { id: "tokyo", label: "Tokyo", country: "Japan", icon: "🗼" },
  { id: "paris", label: "Paris", country: "France", icon: "🗼" },
  { id: "new-york", label: "New York", country: "USA", icon: "🗽" },
  { id: "london", label: "London", country: "UK", icon: "🎡" },
  { id: "rome", label: "Rome", country: "Italy", icon: "🏛️" },
  { id: "barcelona", label: "Barcelona", country: "Spain", icon: "⛪" },
  { id: "bangkok", label: "Bangkok", country: "Thailand", icon: "🛕" },
  { id: "sydney", label: "Sydney", country: "Australia", icon: "🌉" },
]

const DIETARY_RESTRICTIONS = [
  { id: "vegetarian", label: "Vegetarian" },
  { id: "vegan", label: "Vegan" },
  { id: "halal", label: "Halal" },
  { id: "kosher", label: "Kosher" },
  { id: "gluten-free", label: "Gluten-Free" },
  { id: "dairy-free", label: "Dairy-Free" },
  { id: "none", label: "No restrictions" },
]

interface OnboardingFlowProps {
  onComplete: () => void
  userId: string
}

export function OnboardingFlow({ onComplete, userId }: OnboardingFlowProps) {
  const [step, setStep] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [data, setData] = useState<OnboardingData>({
    firstName: "",
    lastName: "",
    travelStyle: "balanced",
    interests: [],
    favoriteDestinations: [],
    travelBudget: "mid-range",
    preferredTripLength: "week",
    travelCompanions: "solo",
    dietaryRestrictions: [],
  })

  const steps = [
    { title: "Welcome", icon: Compass },
    { title: "About You", icon: User },
    { title: "Travel Style", icon: MapPin },
    { title: "Interests", icon: Sparkles },
    { title: "Destinations", icon: MapPin },
    { title: "Preferences", icon: Utensils },
  ]

  const updateData = (updates: Partial<OnboardingData>) => {
    setData((prev) => ({ ...prev, ...updates }))
  }

  const toggleArrayItem = (
    field: "interests" | "favoriteDestinations" | "dietaryRestrictions",
    item: string
  ) => {
    setData((prev) => ({
      ...prev,
      [field]: prev[field].includes(item)
        ? prev[field].filter((i) => i !== item)
        : [...prev[field], item],
    }))
  }

  const canProceed = () => {
    switch (step) {
      case 1:
        return data.firstName.trim().length > 0
      case 3:
        return data.interests.length > 0
      default:
        return true
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
      const supabase = createClient()
      
      const { error } = await supabase
        .from("profiles")
        .update({
          first_name: data.firstName,
          last_name: data.lastName,
          travel_style: data.travelStyle,
          interests: data.interests,
          favorite_destinations: data.favoriteDestinations,
          travel_budget: data.travelBudget,
          preferred_trip_length: data.preferredTripLength,
          travel_companions: data.travelCompanions,
          dietary_restrictions: data.dietaryRestrictions,
          onboarding_completed: true,
        })
        .eq("id", userId)

      if (error) {
        console.error("[v0] Error saving onboarding:", error)
        throw error
      }

      onComplete()
    } catch (error) {
      console.error("[v0] Onboarding failed:", error)
      setIsSubmitting(false)
    }
  }

  const nextStep = () => {
    if (step === steps.length - 1) {
      handleSubmit()
    } else {
      setStep((s) => s + 1)
    }
  }

  const prevStep = () => {
    setStep((s) => Math.max(0, s - 1))
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-2xl">
        {/* Progress indicator */}
        <div className="mb-8 flex items-center justify-center gap-2">
          {steps.map((s, i) => (
            <div
              key={i}
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-full transition-all",
                i < step
                  ? "bg-primary text-primary-foreground"
                  : i === step
                  ? "bg-primary/20 text-primary ring-2 ring-primary ring-offset-2"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {i < step ? (
                <Check className="h-5 w-5" />
              ) : (
                <s.icon className="h-5 w-5" />
              )}
            </div>
          ))}
        </div>

        <Card className="border-0 shadow-xl">
          <CardContent className="p-8">
            {/* Step 0: Welcome */}
            {step === 0 && (
              <div className="text-center">
                <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-primary">
                  <Compass className="h-10 w-10 text-primary-foreground" />
                </div>
                <h1 className="mb-3 text-3xl font-bold">Welcome to Loopin</h1>
                <p className="mb-8 text-lg text-muted-foreground">
                  Let&apos;s personalize your travel experience. This will only take a minute.
                </p>
                <div className="grid gap-4 text-left">
                  <div className="flex items-start gap-4 rounded-lg border p-4">
                    <Sparkles className="mt-0.5 h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Discover Hidden Gems</p>
                      <p className="text-sm text-muted-foreground">
                        Get personalized recommendations for places most travelers miss
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 rounded-lg border p-4">
                    <MapPin className="mt-0.5 h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Smart Itineraries</p>
                      <p className="text-sm text-muted-foreground">
                        AI-optimized routes that save time and money
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 rounded-lg border p-4">
                    <Users className="mt-0.5 h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Connect with Travelers</p>
                      <p className="text-sm text-muted-foreground">
                        Meet like-minded people exploring the same cities
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 1: About You */}
            {step === 1 && (
              <div>
                <h2 className="mb-2 text-2xl font-bold">Tell us about yourself</h2>
                <p className="mb-8 text-muted-foreground">
                  What should we call you?
                </p>
                <div className="space-y-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First name *</Label>
                      <Input
                        id="firstName"
                        value={data.firstName}
                        onChange={(e) => updateData({ firstName: e.target.value })}
                        placeholder="Enter your first name"
                        className="h-12"
                        autoFocus
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last name</Label>
                      <Input
                        id="lastName"
                        value={data.lastName}
                        onChange={(e) => updateData({ lastName: e.target.value })}
                        placeholder="Enter your last name"
                        className="h-12"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Travel Style */}
            {step === 2 && (
              <div>
                <h2 className="mb-2 text-2xl font-bold">What&apos;s your travel pace?</h2>
                <p className="mb-8 text-muted-foreground">
                  This helps us plan the right number of activities per day
                </p>
                <RadioGroup
                  value={data.travelStyle}
                  onValueChange={(v) => updateData({ travelStyle: v })}
                  className="grid gap-4"
                >
                  {[
                    {
                      value: "relaxed",
                      title: "Relaxed",
                      desc: "2-3 activities per day, plenty of downtime",
                      icon: "🧘",
                    },
                    {
                      value: "balanced",
                      title: "Balanced",
                      desc: "4-5 activities per day, mix of exploration and rest",
                      icon: "⚖️",
                    },
                    {
                      value: "packed",
                      title: "Packed",
                      desc: "6+ activities per day, see as much as possible",
                      icon: "🚀",
                    },
                  ].map((style) => (
                    <Label
                      key={style.value}
                      htmlFor={style.value}
                      className={cn(
                        "flex cursor-pointer items-center gap-4 rounded-lg border p-4 transition-all hover:bg-muted/50",
                        data.travelStyle === style.value &&
                          "border-primary bg-primary/5 ring-1 ring-primary"
                      )}
                    >
                      <RadioGroupItem value={style.value} id={style.value} className="sr-only" />
                      <span className="text-3xl">{style.icon}</span>
                      <div className="flex-1">
                        <p className="font-medium">{style.title}</p>
                        <p className="text-sm text-muted-foreground">{style.desc}</p>
                      </div>
                      {data.travelStyle === style.value && (
                        <Check className="h-5 w-5 text-primary" />
                      )}
                    </Label>
                  ))}
                </RadioGroup>
              </div>
            )}

            {/* Step 3: Interests */}
            {step === 3 && (
              <div>
                <h2 className="mb-2 text-2xl font-bold">What interests you?</h2>
                <p className="mb-8 text-muted-foreground">
                  Select at least one to get personalized recommendations
                </p>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {INTERESTS.map((interest) => (
                    <button
                      key={interest.id}
                      type="button"
                      onClick={() => toggleArrayItem("interests", interest.id)}
                      className={cn(
                        "flex flex-col items-center gap-2 rounded-xl border p-4 transition-all hover:bg-muted/50",
                        data.interests.includes(interest.id) &&
                          "border-primary bg-primary/5 ring-1 ring-primary"
                      )}
                    >
                      <span className="text-2xl">{interest.icon}</span>
                      <span className="text-sm font-medium">{interest.label}</span>
                      {data.interests.includes(interest.id) && (
                        <Check className="h-4 w-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 4: Favorite Destinations */}
            {step === 4 && (
              <div>
                <h2 className="mb-2 text-2xl font-bold">Dream destinations?</h2>
                <p className="mb-8 text-muted-foreground">
                  Select cities you&apos;d love to explore (optional)
                </p>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {DESTINATIONS.map((dest) => (
                    <button
                      key={dest.id}
                      type="button"
                      onClick={() => toggleArrayItem("favoriteDestinations", dest.id)}
                      className={cn(
                        "flex flex-col items-center gap-2 rounded-xl border p-4 transition-all hover:bg-muted/50",
                        data.favoriteDestinations.includes(dest.id) &&
                          "border-primary bg-primary/5 ring-1 ring-primary"
                      )}
                    >
                      <span className="text-2xl">{dest.icon}</span>
                      <span className="text-sm font-medium">{dest.label}</span>
                      <span className="text-xs text-muted-foreground">{dest.country}</span>
                      {data.favoriteDestinations.includes(dest.id) && (
                        <Check className="h-4 w-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 5: Additional Preferences */}
            {step === 5 && (
              <div>
                <h2 className="mb-2 text-2xl font-bold">Almost done!</h2>
                <p className="mb-8 text-muted-foreground">
                  A few more details to personalize your experience
                </p>
                <div className="space-y-6">
                  {/* Budget */}
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Wallet className="h-4 w-4" />
                      Budget preference
                    </Label>
                    <RadioGroup
                      value={data.travelBudget}
                      onValueChange={(v) => updateData({ travelBudget: v })}
                      className="flex gap-3"
                    >
                      {[
                        { value: "budget", label: "Budget", icon: "$" },
                        { value: "mid-range", label: "Mid-range", icon: "$$" },
                        { value: "luxury", label: "Luxury", icon: "$$$" },
                      ].map((opt) => (
                        <Label
                          key={opt.value}
                          className={cn(
                            "flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-lg border p-3 transition-all hover:bg-muted/50",
                            data.travelBudget === opt.value &&
                              "border-primary bg-primary/5"
                          )}
                        >
                          <RadioGroupItem value={opt.value} className="sr-only" />
                          <span className="font-mono text-sm text-primary">{opt.icon}</span>
                          <span className="text-sm">{opt.label}</span>
                        </Label>
                      ))}
                    </RadioGroup>
                  </div>

                  {/* Trip Length */}
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Typical trip length
                    </Label>
                    <RadioGroup
                      value={data.preferredTripLength}
                      onValueChange={(v) => updateData({ preferredTripLength: v })}
                      className="flex gap-3"
                    >
                      {[
                        { value: "weekend", label: "Weekend" },
                        { value: "week", label: "1 Week" },
                        { value: "extended", label: "2+ Weeks" },
                      ].map((opt) => (
                        <Label
                          key={opt.value}
                          className={cn(
                            "flex flex-1 cursor-pointer items-center justify-center rounded-lg border p-3 transition-all hover:bg-muted/50",
                            data.preferredTripLength === opt.value &&
                              "border-primary bg-primary/5"
                          )}
                        >
                          <RadioGroupItem value={opt.value} className="sr-only" />
                          <span className="text-sm">{opt.label}</span>
                        </Label>
                      ))}
                    </RadioGroup>
                  </div>

                  {/* Travel Companions */}
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Usually travel with
                    </Label>
                    <RadioGroup
                      value={data.travelCompanions}
                      onValueChange={(v) => updateData({ travelCompanions: v })}
                      className="flex gap-3"
                    >
                      {[
                        { value: "solo", label: "Solo" },
                        { value: "partner", label: "Partner" },
                        { value: "family", label: "Family" },
                        { value: "friends", label: "Friends" },
                      ].map((opt) => (
                        <Label
                          key={opt.value}
                          className={cn(
                            "flex flex-1 cursor-pointer items-center justify-center rounded-lg border p-3 transition-all hover:bg-muted/50",
                            data.travelCompanions === opt.value &&
                              "border-primary bg-primary/5"
                          )}
                        >
                          <RadioGroupItem value={opt.value} className="sr-only" />
                          <span className="text-sm">{opt.label}</span>
                        </Label>
                      ))}
                    </RadioGroup>
                  </div>

                  {/* Dietary Restrictions */}
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Utensils className="h-4 w-4" />
                      Dietary preferences
                    </Label>
                    <div className="flex flex-wrap gap-2">
                      {DIETARY_RESTRICTIONS.map((diet) => (
                        <button
                          key={diet.id}
                          type="button"
                          onClick={() => toggleArrayItem("dietaryRestrictions", diet.id)}
                          className={cn(
                            "rounded-full border px-4 py-2 text-sm transition-all hover:bg-muted/50",
                            data.dietaryRestrictions.includes(diet.id) &&
                              "border-primary bg-primary/10 text-primary"
                          )}
                        >
                          {diet.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="mt-8 flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={prevStep}
                disabled={step === 0}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                onClick={nextStep}
                disabled={!canProceed() || isSubmitting}
                className="gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : step === steps.length - 1 ? (
                  <>
                    Get Started
                    <Sparkles className="h-4 w-4" />
                  </>
                ) : (
                  <>
                    Continue
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
